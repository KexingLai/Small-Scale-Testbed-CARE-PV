%Created on Thu Sep 12 15:16:29 2019

%author: sai
clear all
clc

DSSObj = actxserver('OpenDSSEngine.DSS');

% Start the OpenDSS
if ~DSSObj.Start(0)
    disp('Unable to start the OpenDSS Engine')
    return
end

% Set up the Text, Circuit, and Solution Interfaces
DSSText = DSSObj.Text;
DSSCircuit = DSSObj.ActiveCircuit;
DSSSolution = DSSCircuit.Solution;

% Run ieee37.dss configuration file 
DSSText.Command = 'Compile (C:\Users\zhanghang.USERS\Dropbox\CARE-PV\Small scale test system\New Test System\codes\559 node.dss)';

DSSText.Command = 'New Energymeter.m1 Line.L35 1';          % one has to enable this to plot the voltage profile (enable distance to sub)

DSSText.Command = 'Set Maxiterations=50';
DSSText.Command = 'Set maxcontrol=50';


%% Solve the network 

DSSSolution.Solve;
if DSSSolution.Converged,
    disp('The Circuit Solved Successfully')
end

%% voltage angle
% Grab bus voltages (and names, for reference)

v = DSSCircuit.AllBusVolts

% Convert to complex
% v = reshape(v,2,[])';
% v = v .* ones(size(v))*[1; j];
%     
% % Grab angles (in radians)
% ang = angle(v)
%% Export output files

% Export voltage to a csv file
DSSText.Command = 'Export Voltages';

v = DSSCircuit.AllBusVolts;
v = reshape(v,2,[])';
v = v/2771.3;

v(:,3)=abs(v(:,1)+v(:,2)*1i);
v(:,4)=angle(v(:,1)+v(:,2)*1i);
v(:,4)=v(:,4)*(180/pi);

% DSSText.Command = 'Export Power';
% 
% voltable = readtable('C:\Users\saimunikoti\Manifestation\DOE_Work\PVSA\pvsa_3phase\docs\Opendss_Files\ieee37_EXP_VOLTAGES.CSV');
%
% separate into three different matrix
voltphase1=zeros(36,2);
voltphase2=zeros(36,2);
voltphase3=zeros(36,2);
j=1
for iind=1:3:109
    jind = iind+1;
    kind = iind+2;
    voltphase1(j,:)=v(iind,3:4);
    voltphase2(j,:)=v(jind,3:4);
    voltphase3(j,:)=v(kind,3:4);
    j=j+1;
end

voltable =[voltphase1 voltphase2 voltphase3];
voltable(:,7)= [1;10;24;2;3;25;28;4;5;9;29;30;32;27;26;33;34;35;37;36;11;13;12;23;15;16;17;20;22;21;31;6;14;18;19;7;8];    
voltable = sortrows(voltable,7);

% base kv of xmer is 277.13kv so multiply it by factor of 10
% for iind=1:2:5
%     voltable(24,iind)=voltable(24,iind)*10;
% end
%% Plot of voltages for three phase

plot(voltable(:,1),'k');  % black *
hold on;
plot(voltable(:,3), 'r');  % red +
plot(voltable(:,5), 'b');  % diamond Marker

legend('phase A','phase B','phase C','Location','SouthEast'); %put the legend
title('Voltage Profile Plot'); %plot title

ylim([0.94 1.01]);
ylabel('Volts(pu)');
xlabel('Distance from Substation');

hold off

figure (2)
plot(voltable(:,2),'k');  % black *
hold on;
plot(voltable(:,4)+120, 'r');  % red +
plot(voltable(:,6)-120, 'b');  % diamond Marker

legend('phase A','phase B','phase C','Location','SouthEast'); %put the legend
title('Angle Profile Plot'); %plot title

ylabel('Angle');
xlabel('Distance from Substation');

hold off

