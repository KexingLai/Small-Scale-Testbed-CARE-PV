%% line impedance
% z721 has been replaced with : 556 ACSR (configuration 601 in IEEE 13) Configuration 601

new_z721 = [ 0.3465+1j*1.0179   0.1560+1j*0.5017   0.1580+1j*0.4236             
         0.1560+1j*0.5017   0.3375+1j*1.0478   0.1535+1j*0.3849          
         0.1580+1j*0.4236   0.1535+1j*0.3849   0.3414+1j*1.0348 ];% ohm per mile   
     

% z722 has been replaced with : 336.4 ACSR (configuration 1 in IEEE 123) Configuration 1:

new_z722 = [ 0.4576+1j*1.0780   0.1560+1j*0.5017   0.1535+1j*0.3849                  
         0.1560+1j*0.5017   0.4666+1j*1.0482   0.1580+1j*0.4236         
         0.1535+1j*0.3849   0.1580+1j*0.4236   0.4615+1j*1.0651 ];% ohm per mile   
     
 
% z723 has been replaced with : 1/0 ACSR (configuration 300 in IEEE 34) Configuration 300

     
new_z723 = [ 1.3368+1j*1.3343   0.2101+1j*0.5779   0.2130+1j*0.5015              
         0.2101+1j*0.5779   1.3238+1j*1.3569   0.2066+1j*0.4591         
         0.2130+1j*0.5015   0.2066+1j*0.4591   1.3294+1j*1.3471 ];% ohm per mile    
     
     
     
% z724 has been replaced with : #2 ACSR (configuration 301 in IEEE 34) Configuration 301    
     
new_z724 = [ 1.9300+1j*1.4115   0.2327+1j*0.6442   0.2359+1j*0.5691                
         0.2327+1j*0.6442   1.9157+1j*1.4281   0.2288+1j*0.5238          
         0.2359+1j*0.5691   0.2288+1j*0.5238   1.9219+1j*1.4209 ];% ohm per mile   

z725 = [ 1.6033 + 1j*1.3873   0   0
         0   1.6033 + 1j*1.3873   0
         0   0   1.6033 + 1j*1.3873 ];% primary % ohm per mile
     
z726 = [ 1.10888 + 1j*0.2357   0   0
         0   1.10888 + 1j*0.2357   0
         0   0   1.10888 + 1j*0.2357 ]*((4800/sqrt(3))/240);%secondary % ohm per mile

z727 = [ 3.456 + 1j*3.31776   0   0
         0   3.456 + 1j*3.31776   0
         0   0   3.456 + 1j*3.31776 ];%Transformer Impedance in ohm
